package com.umanizales.demo.model;

public enum Gender {
    MASCULINO, FEMENINO;
}
