package com.umanizales.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ListDeApplicationTests {

    @Test
    void contextLoads() {
    }

}
