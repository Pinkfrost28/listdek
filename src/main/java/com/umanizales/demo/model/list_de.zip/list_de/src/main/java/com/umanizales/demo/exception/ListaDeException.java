package com.umanizales.demo.exception;

public class ListaDeException extends Exception{
    public ListaDeException(String message) {
        super(message);
    }
}
