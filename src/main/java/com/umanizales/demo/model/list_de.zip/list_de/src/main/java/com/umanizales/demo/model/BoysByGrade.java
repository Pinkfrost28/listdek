package com.umanizales.demo.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class BoysByGrade {
    private int grade;
    private int count;
}
