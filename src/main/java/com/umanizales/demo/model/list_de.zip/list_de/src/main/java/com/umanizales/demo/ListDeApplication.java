package com.umanizales.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ListDeApplication {

    public static void main(String[] args) {
        SpringApplication.run(ListDeApplication.class, args);
    }

}
